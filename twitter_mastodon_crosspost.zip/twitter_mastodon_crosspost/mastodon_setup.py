"""
Mastodon 앱 등록 & 액세스 토큰 발급 도우미
============================================
처음 한 번만 실행하면 됩니다.
실행 후 출력된 값을 .env 파일에 복사하세요.

사용법:
    python mastodon_setup.py
"""

from mastodon import Mastodon

# ─── 설정 ─────────────────────────────────────────────────
INSTANCE_URL = input("마스토돈 인스턴스 URL (예: https://mastodon.social): ").strip()
EMAIL        = input("마스토돈 계정 이메일: ").strip()
PASSWORD     = input("마스토돈 계정 비밀번호: ").strip()
APP_NAME     = "TwitterCrossposter"
# ──────────────────────────────────────────────────────────

print("\n[1/3] 앱 등록 중...")
Mastodon.create_app(
    APP_NAME,
    api_base_url=INSTANCE_URL,
    to_file="mastodon_clientcred.secret",
)

print("[2/3] 로그인 및 액세스 토큰 발급 중...")
mastodon = Mastodon(
    client_id="mastodon_clientcred.secret",
    api_base_url=INSTANCE_URL,
)
mastodon.log_in(
    EMAIL,
    PASSWORD,
    to_file="mastodon_usercred.secret",
)

# secret 파일에서 값 읽기
import re
client_data = open("mastodon_clientcred.secret").read().splitlines()
user_data   = open("mastodon_usercred.secret").read().splitlines()

print("\n" + "=" * 50)
print("✅ 발급 완료! 아래 값을 .env 파일에 복사하세요")
print("=" * 50)
print(f"MASTODON_API_BASE_URL={INSTANCE_URL}")
print(f"MASTODON_CLIENT_ID={client_data[0]}")
print(f"MASTODON_CLIENT_SECRET={client_data[1]}")
print(f"MASTODON_ACCESS_TOKEN={user_data[0]}")
print("=" * 50)
print("\n※ mastodon_clientcred.secret, mastodon_usercred.secret 파일은 삭제해도 됩니다.")
