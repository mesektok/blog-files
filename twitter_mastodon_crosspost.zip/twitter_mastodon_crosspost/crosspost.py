"""
Twitter → Mastodon 자동 크로스포스팅 스크립트
=============================================
필요 라이브러리: tweepy, Mastodon.py, python-dotenv

설치: pip install tweepy Mastodon.py python-dotenv
"""

import os
import time
import json
import logging
import re
from pathlib import Path
from datetime import datetime, timezone

import tweepy
from mastodon import Mastodon
from dotenv import load_dotenv

# ─────────────────────────────────────────────
# 로깅 설정
# ─────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler("crosspost.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# 환경변수 로드 (.env 파일)
# ─────────────────────────────────────────────
load_dotenv()

TWITTER_BEARER_TOKEN      = os.getenv("TWITTER_BEARER_TOKEN")
TWITTER_API_KEY           = os.getenv("TWITTER_API_KEY")
TWITTER_API_SECRET        = os.getenv("TWITTER_API_SECRET")
TWITTER_ACCESS_TOKEN      = os.getenv("TWITTER_ACCESS_TOKEN")
TWITTER_ACCESS_SECRET     = os.getenv("TWITTER_ACCESS_SECRET")
TWITTER_USER_ID           = os.getenv("TWITTER_USER_ID")       # 숫자 형식 User ID

MASTODON_CLIENT_ID        = os.getenv("MASTODON_CLIENT_ID")
MASTODON_CLIENT_SECRET    = os.getenv("MASTODON_CLIENT_SECRET")
MASTODON_ACCESS_TOKEN     = os.getenv("MASTODON_ACCESS_TOKEN")
MASTODON_API_BASE_URL     = os.getenv("MASTODON_API_BASE_URL", "https://mastodon.social")

# 마지막으로 처리한 트윗 ID를 저장하는 파일
STATE_FILE = Path("last_tweet_id.json")

# 폴링 간격 (초). 트위터 API Free 티어는 15분에 1회 권장
POLL_INTERVAL_SECONDS = int(os.getenv("POLL_INTERVAL_SECONDS", "900"))

# 크로스포스팅 제외 키워드 (소문자). 해당 단어 포함 트윗은 건너뜀
EXCLUDE_KEYWORDS = [kw.strip() for kw in os.getenv("EXCLUDE_KEYWORDS", "").split(",") if kw.strip()]

# 리트윗 포함 여부 (기본: 제외)
INCLUDE_RETWEETS  = os.getenv("INCLUDE_RETWEETS", "false").lower() == "true"

# 답글(Reply) 포함 여부 (기본: 제외)
INCLUDE_REPLIES   = os.getenv("INCLUDE_REPLIES", "false").lower() == "true"


# ─────────────────────────────────────────────
# 상태 파일 유틸리티
# ─────────────────────────────────────────────

def load_last_tweet_id() -> str | None:
    """마지막으로 처리한 트윗 ID를 파일에서 읽어옴."""
    if STATE_FILE.exists():
        try:
            data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            return data.get("last_tweet_id")
        except Exception:
            return None
    return None


def save_last_tweet_id(tweet_id: str) -> None:
    """마지막으로 처리한 트윗 ID를 파일에 저장."""
    STATE_FILE.write_text(
        json.dumps({"last_tweet_id": tweet_id, "updated_at": datetime.now(timezone.utc).isoformat()}),
        encoding="utf-8",
    )


# ─────────────────────────────────────────────
# Twitter 클라이언트 초기화
# ─────────────────────────────────────────────

def build_twitter_client() -> tweepy.Client:
    """Tweepy v2 Client 반환."""
    client = tweepy.Client(
        bearer_token=TWITTER_BEARER_TOKEN,
        consumer_key=TWITTER_API_KEY,
        consumer_secret=TWITTER_API_SECRET,
        access_token=TWITTER_ACCESS_TOKEN,
        access_token_secret=TWITTER_ACCESS_SECRET,
        wait_on_rate_limit=True,
    )
    return client


# ─────────────────────────────────────────────
# Mastodon 클라이언트 초기화
# ─────────────────────────────────────────────

def build_mastodon_client() -> Mastodon:
    """Mastodon.py 클라이언트 반환."""
    mastodon = Mastodon(
        client_id=MASTODON_CLIENT_ID,
        client_secret=MASTODON_CLIENT_SECRET,
        access_token=MASTODON_ACCESS_TOKEN,
        api_base_url=MASTODON_API_BASE_URL,
    )
    return mastodon


# ─────────────────────────────────────────────
# 트윗 텍스트 정제
# ─────────────────────────────────────────────

def clean_tweet_text(text: str) -> str:
    """
    트윗 텍스트를 마스토돈에 맞게 정제.
    - t.co 단축 URL을 원본 URL로 교체 (tweepy expand_urls 사용 시 자동 처리됨)
    - 불필요한 공백 정리
    """
    # 연속 공백·개행 정리
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = text.strip()
    return text


def should_skip(tweet) -> bool:
    """
    크로스포스팅을 건너뛸 트윗인지 판단.
    Returns True → 건너뜀, False → 게시
    """
    text = (tweet.text or "").lower()

    # 리트윗 제외
    if not INCLUDE_RETWEETS and tweet.text.startswith("RT @"):
        logger.debug(f"[SKIP] 리트윗: {tweet.id}")
        return True

    # 답글 제외
    if not INCLUDE_REPLIES and tweet.in_reply_to_user_id:
        logger.debug(f"[SKIP] 답글: {tweet.id}")
        return True

    # 제외 키워드
    for kw in EXCLUDE_KEYWORDS:
        if kw in text:
            logger.debug(f"[SKIP] 제외 키워드 '{kw}' 포함: {tweet.id}")
            return True

    return False


# ─────────────────────────────────────────────
# 트윗 가져오기
# ─────────────────────────────────────────────

def fetch_new_tweets(client: tweepy.Client, since_id: str | None) -> list:
    """
    since_id 이후의 새 트윗을 최대 100개 가져옴.
    오래된 순서로 반환 (시간순 크로스포스팅).
    """
    kwargs = dict(
        id=TWITTER_USER_ID,
        max_results=100,
        tweet_fields=["created_at", "in_reply_to_user_id", "entities"],
        expansions=["attachments.media_keys"],
        media_fields=["url", "preview_image_url", "type"],
    )
    if since_id:
        kwargs["since_id"] = since_id

    try:
        response = client.get_users_tweets(**kwargs)
    except tweepy.errors.TweepyException as e:
        logger.error(f"Twitter API 오류: {e}")
        return []

    tweets = response.data or []
    # 오래된 것부터 처리
    tweets.sort(key=lambda t: t.id)
    return tweets


# ─────────────────────────────────────────────
# 마스토돈에 게시
# ─────────────────────────────────────────────

def post_to_mastodon(mastodon: Mastodon, tweet) -> bool:
    """
    단일 트윗을 마스토돈에 게시.
    성공 시 True, 실패 시 False 반환.
    """
    text = clean_tweet_text(tweet.text)

    # 트위터 원본 링크 추가 (선택적)
    tweet_url = f"https://twitter.com/i/web/status/{tweet.id}"
    status_text = f"{text}\n\n🐦 원문: {tweet_url}"

    # 마스토돈 글자 수 제한 (기본 500자)
    if len(status_text) > 500:
        # 원문 링크가 들어갈 공간 확보 후 자름
        max_text = 500 - len(f"\n\n🐦 원문: {tweet_url}") - 3
        status_text = f"{text[:max_text]}...\n\n🐦 원문: {tweet_url}"

    try:
        mastodon.status_post(status=status_text, visibility="public")
        logger.info(f"[POST] 마스토돈 게시 완료 | 트윗 ID: {tweet.id} | {text[:60]}...")
        return True
    except Exception as e:
        logger.error(f"[ERROR] 마스토돈 게시 실패 | 트윗 ID: {tweet.id} | {e}")
        return False


# ─────────────────────────────────────────────
# 메인 루프
# ─────────────────────────────────────────────

def run():
    """트위터 폴링 → 마스토돈 크로스포스팅 메인 루프."""
    logger.info("=" * 50)
    logger.info("Twitter → Mastodon Crosspost 시작")
    logger.info(f"폴링 간격: {POLL_INTERVAL_SECONDS}초 | 제외 키워드: {EXCLUDE_KEYWORDS or '없음'}")
    logger.info("=" * 50)

    twitter  = build_twitter_client()
    mastodon = build_mastodon_client()

    while True:
        since_id = load_last_tweet_id()
        logger.info(f"새 트윗 확인 중... (since_id={since_id})")

        tweets = fetch_new_tweets(twitter, since_id)

        if not tweets:
            logger.info("새 트윗 없음.")
        else:
            logger.info(f"{len(tweets)}개의 새 트윗 발견.")
            new_last_id = since_id

            for tweet in tweets:
                if should_skip(tweet):
                    # 건너뛰더라도 ID는 업데이트
                    new_last_id = str(tweet.id)
                    continue

                success = post_to_mastodon(mastodon, tweet)
                if success:
                    new_last_id = str(tweet.id)
                    time.sleep(2)  # 마스토돈 API rate limit 방지

            if new_last_id and new_last_id != since_id:
                save_last_tweet_id(new_last_id)
                logger.info(f"상태 저장: last_tweet_id = {new_last_id}")

        logger.info(f"다음 확인까지 {POLL_INTERVAL_SECONDS}초 대기...\n")
        time.sleep(POLL_INTERVAL_SECONDS)


if __name__ == "__main__":
    run()
